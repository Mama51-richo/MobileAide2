package com.mobileaide

import android.content.Context

enum class AppRole { OWNER, ADMIN, OPERATOR, VIEWER }

/**
 * DEMO ROLE GATE ONLY. Local role selection is not authentication.
 * Before production, replace with server-verified identity and authorization.
 */
class RoleManager(context: Context) {
    private val prefs = context.getSharedPreferences("mobileaide_demo_role", Context.MODE_PRIVATE)
    fun currentRole(): AppRole = runCatching {
        AppRole.valueOf(prefs.getString("role", AppRole.OWNER.name) ?: AppRole.OWNER.name)
    }.getOrDefault(AppRole.VIEWER)

    fun setDemoRole(role: AppRole) {
        prefs.edit().putString("role", role.name).apply()
    }

    fun canConfigure(): Boolean = currentRole() == AppRole.OWNER || currentRole() == AppRole.ADMIN
    fun canExport(): Boolean = currentRole() != AppRole.VIEWER
    fun canViewEvents(): Boolean = true
}
