package com.mobileaide

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var eventsText: TextView
    private lateinit var roleSpinner: Spinner
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var store: SecureEventStore
    private lateinit var roles: RoleManager
    private var imageCapture: ImageCapture? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var backCamera = true
    private var motionEnabled = true
    private var lastMotionSaved = 0L

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else {
            status.text = "Camera permission denied. Live CCTV is unavailable."
            Toast.makeText(this, "Allow camera access in Android Settings to use MobileAide.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SecureEventStore(this)
        roles = RoleManager(this)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 24)
            setBackgroundColor(Color.rgb(7, 21, 38))
        }
        scroll.addView(root)
        setContentView(scroll)

        val heading = TextView(this).apply {
            text = "MobileAide"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(heading, matchWrap())
        root.addView(TextView(this).apply {
            text = "AI Pocket CCTV & Scene Analyst"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
        }, matchWrap())

        status = TextView(this).apply {
            text = "Starting camera…"
            textSize = 14f
            setTextColor(Color.rgb(100, 220, 190))
            setPadding(0, 16, 0, 12)
        }
        root.addView(status, matchWrap())

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(previewView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(300)
        ))

        val cameraRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cameraRow.addView(actionButton("Switch camera") {
            backCamera = !backCamera
            startCamera()
        }, weighted())
        cameraRow.addView(actionButton("Motion alerts: ON") {
            motionEnabled = !motionEnabled
            (it as Button).text = if (motionEnabled) "Motion alerts: ON" else "Motion alerts: OFF"
            status.text = if (motionEnabled) "Motion monitoring enabled (basic pixel-change detection)." else "Motion monitoring paused."
        }, weighted())
        root.addView(cameraRow, matchWrap())

        root.addView(sectionTitle("Admin access (demo only)"))
        roleSpinner = Spinner(this)
        roleSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, AppRole.values().map { it.name })
        roleSpinner.setSelection(AppRole.values().indexOf(roles.currentRole()))
        roleSpinner.onItemSelectedListener = SimpleSelectionListener { value ->
            roles.setDemoRole(runCatching { AppRole.valueOf(value) }.getOrDefault(AppRole.VIEWER))
            status.text = "Current demo role: ${roles.currentRole()}. This is not secure authentication."
        }
        root.addView(roleSpinner, matchWrap())
        root.addView(TextView(this).apply {
            text = "Production warning: role selection here is only a UI demo. Enforce Owner/Admin/Operator/Viewer permissions on a trusted backend."
            setTextColor(Color.rgb(255, 190, 110))
            textSize = 12f
            setPadding(0, 4, 0, 10)
        }, matchWrap())

        root.addView(sectionTitle("Event timeline"))
        eventsText = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(16, 38, 59))
        }
        root.addView(eventsText, matchWrap())
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(actionButton("Refresh") { refreshEvents() }, weighted())
        bottom.addView(actionButton("Delete events") {
            if (roles.canConfigure()) {
                store.clearAll()
                refreshEvents()
                Toast.makeText(this, "Local event history deleted.", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this, "Only Owner/Admin can delete event data.", Toast.LENGTH_SHORT).show()
        }, weighted())
        root.addView(bottom, matchWrap())
        refreshEvents()
    }

    private fun startCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(cameraExecutor, MotionAnalyzer {
                    runOnUiThread { onMotionDetected() }
                })
                val selector = if (backCamera) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, imageCapture, analysis)
                status.text = "LIVE • Camera active • Motion detection is a basic heuristic"
            } catch (e: Exception) {
                status.text = "Camera could not start: ${e.localizedMessage ?: "unknown error"}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun onMotionDetected() {
        if (!motionEnabled || System.currentTimeMillis() - lastMotionSaved < 5_000) return
        lastMotionSaved = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        val capture = imageCapture ?: return
        val temp = File(cacheDir, "$id.jpg")
        capture.takePicture(
            ImageCapture.OutputFileOptions.Builder(temp).build(),
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    try {
                        val encryptedPath = store.saveEncryptedSnapshot(temp.readBytes(), id)
                        val event = SecurityEvent(
                            id = id,
                            timestamp = System.currentTimeMillis(),
                            type = "MOTION",
                            confidence = 0.0f,
                            detail = "Pixel-change motion heuristic; not a person/vehicle classification.",
                            snapshotFile = encryptedPath
                        )
                        store.addEvent(event)
                        status.text = "Motion event saved locally (encrypted snapshot)."
                        refreshEvents()
                    } catch (e: Exception) {
                        status.text = "Event save failed: ${e.localizedMessage ?: "storage error"}"
                    } finally { temp.delete() }
                }
                override fun onError(exception: ImageCaptureException) {
                    temp.delete()
                    status.text = "Snapshot failed: ${exception.message ?: "camera error"}"
                }
            }
        )
    }

    private fun refreshEvents() {
        val events = store.allEvents()
        eventsText.text = if (events.isEmpty()) "No events yet. Motion events appear when the scene changes." else
            events.take(30).joinToString("\n\n") { event ->
                val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(event.timestamp))
                "• $date\n${event.type} · ${event.detail}\nSnapshot: ${if (event.snapshotFile != null) "encrypted local file" else "none"}"
            }
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 18f
        setTextColor(Color.WHITE)
        setPadding(0, 22, 0, 10)
    }
    private fun actionButton(label: String, action: (View) -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener(action)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
    private fun weighted() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        cameraProvider?.unbindAll()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
