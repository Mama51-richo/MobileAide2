package com.mobileaide

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Optional HTTPS event sync client. Disabled until a real endpoint/token is configured.
 * Never hard-code secrets in the APK; use short-lived authenticated sessions.
 */
class BackendClient(
    private val baseUrl: String,
    private val tokenProvider: () -> String?
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    fun uploadEvent(event: SecurityEvent): Result<String> = runCatching {
        require(baseUrl.startsWith("https://")) { "Backend URL must use HTTPS" }
        val token = tokenProvider()?.takeIf { it.isNotBlank() }
            ?: error("No authenticated session token configured")
        val body = JSONObject().apply {
            put("id", event.id)
            put("timestamp", event.timestamp)
            put("type", event.type)
            put("confidence", event.confidence.toDouble())
            put("detail", event.detail)
        }.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(baseUrl.trimEnd('/') + "/api/events")
            .header("Authorization", "Bearer $token")
            .post(body)
            .build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Backend returned HTTP ${response.code}")
            response.body?.string().orEmpty()
        }
    }
}
