package com.mobileaide

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class SecurityEvent(
    val id: String,
    val timestamp: Long,
    val type: String,
    val confidence: Float,
    val detail: String,
    val snapshotFile: String? = null
)

class SecureEventStore(private val context: Context) {
    private val keyAlias = "mobileaide_event_key"
    private val eventFile = File(context.filesDir, "events.enc")
    private val snapshotDir = File(context.filesDir, "snapshots").apply { mkdirs() }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                keyAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(bytes: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(bytes)
        return ByteArray(4 + iv.size + ciphertext.size).also {
            it[0] = iv.size.toByte()
            System.arraycopy(iv, 0, it, 1, 3)
            // Store IV length as one byte; fixed GCM IV is 12 bytes.
            System.arraycopy(iv, 0, it, 4, iv.size)
            System.arraycopy(ciphertext, 0, it, 4 + iv.size, ciphertext.size)
        }
    }

    private fun decrypt(blob: ByteArray): ByteArray {
        require(blob.size > 16) { "Encrypted data is invalid" }
        val ivLength = blob[0].toInt() and 0xff
        require(ivLength in 12..16 && blob.size > 4 + ivLength) { "Encrypted data header invalid" }
        val iv = blob.copyOfRange(4, 4 + ivLength)
        val ciphertext = blob.copyOfRange(4 + ivLength, blob.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return cipher.doFinal(ciphertext)
    }

    @Synchronized
    fun allEvents(): List<SecurityEvent> {
        if (!eventFile.exists()) return emptyList()
        return try {
            val array = JSONArray(String(decrypt(eventFile.readBytes()), Charsets.UTF_8))
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                SecurityEvent(
                    id = o.getString("id"),
                    timestamp = o.getLong("timestamp"),
                    type = o.getString("type"),
                    confidence = o.optDouble("confidence", 0.0).toFloat(),
                    detail = o.optString("detail", ""),
                    snapshotFile = if (o.isNull("snapshotFile")) null else o.optString("snapshotFile")
                )
            }.sortedByDescending { it.timestamp }
        } catch (_: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun addEvent(event: SecurityEvent) {
        val events = (listOf(event) + allEvents()).take(500)
        val array = JSONArray()
        events.forEach { e ->
            array.put(JSONObject().apply {
                put("id", e.id)
                put("timestamp", e.timestamp)
                put("type", e.type)
                put("confidence", e.confidence.toDouble())
                put("detail", e.detail)
                put("snapshotFile", e.snapshotFile ?: JSONObject.NULL)
            })
        }
        eventFile.writeBytes(encrypt(array.toString().toByteArray(Charsets.UTF_8)))
    }

    fun saveEncryptedSnapshot(jpeg: ByteArray, eventId: String): String {
        val file = File(snapshotDir, "$eventId.jpg.enc")
        file.writeBytes(encrypt(jpeg))
        return file.absolutePath
    }

    fun readEncryptedSnapshot(path: String): ByteArray? = try {
        val file = File(path)
        if (file.exists() && file.canonicalPath.startsWith(snapshotDir.canonicalPath)) {
            decrypt(file.readBytes())
        } else null
    } catch (_: Exception) { null }

    @Synchronized
    fun clearAll() {
        eventFile.delete()
        snapshotDir.listFiles()?.forEach { it.delete() }
    }
}
