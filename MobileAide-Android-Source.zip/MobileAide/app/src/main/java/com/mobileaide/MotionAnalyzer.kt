package com.mobileaide

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

/**
 * Privacy-first baseline motion detector. This is NOT person/vehicle AI.
 * It compares downsampled luminance from consecutive frames and throttles events.
 */
class MotionAnalyzer(
    private val onMotion: () -> Unit
) : ImageAnalysis.Analyzer {
    private var previous: ByteArray? = null
    private val lastEvent = AtomicLong(0L)

    override fun analyze(image: ImageProxy) {
        try {
            val plane = image.planes.firstOrNull() ?: return
            val buffer = plane.buffer
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            val width = image.width
            val height = image.height
            val stepX = (width / 32).coerceAtLeast(1)
            val stepY = (height / 24).coerceAtLeast(1)
            val current = ArrayList<Byte>(32 * 24)
            var y = 0
            while (y < height) {
                var x = 0
                while (x < width) {
                    val index = y * rowStride + x * pixelStride
                    if (index < buffer.limit()) current.add(buffer.get(index))
                    x += stepX
                }
                y += stepY
            }
            val bytes = ByteArray(current.size) { current[it] }
            val old = previous
            previous = bytes
            if (old != null && old.size == bytes.size && bytes.isNotEmpty()) {
                var changed = 0
                for (i in bytes.indices) {
                    if (abs((bytes[i].toInt() and 0xff) - (old[i].toInt() and 0xff)) > 24) changed++
                }
                val ratio = changed.toFloat() / bytes.size
                val now = System.currentTimeMillis()
                if (ratio > 0.12f && now - lastEvent.get() > 5_000L) {
                    lastEvent.set(now)
                    onMotion()
                }
            }
        } catch (_: Exception) {
            // Camera frames can be transiently unavailable; keep analysis alive.
        } finally {
            image.close()
        }
    }
}
